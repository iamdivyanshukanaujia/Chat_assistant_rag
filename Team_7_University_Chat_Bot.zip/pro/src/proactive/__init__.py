"""
Proactive suggestions package.
"""
