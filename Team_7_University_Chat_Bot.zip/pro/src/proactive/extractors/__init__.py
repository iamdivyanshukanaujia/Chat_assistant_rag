"""
Document extractors package.
"""
