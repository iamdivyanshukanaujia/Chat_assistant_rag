"""
Proactive rules package.
"""
