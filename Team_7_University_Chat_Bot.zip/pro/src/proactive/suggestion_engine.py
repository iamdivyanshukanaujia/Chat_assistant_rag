"""
Proactive Suggestion Engine - Main orchestrator for generating suggestions.
"""
from typing import List, Dict
from datetime import datetime

from src.proactive.data_provider import StudentDataProvider
from src.proactive.models import Suggestion
from src.proactive.rules.time_based import DeadlineRule, PlacementSeasonRule
from src.proactive.rules.context_based import (
    AttendanceRule,
    ScholarshipEligibilityRule,
    CGPAPerformanceRule,
    PlacementEligibilityRule
)
from src.utils.logger import get_logger

logger = get_logger(__name__)


class ProactiveSuggestionEngine:
    """Main engine that evaluates all rules and returns personalized suggestions."""
    
    def __init__(self, data_provider: StudentDataProvider):
        """
        Initialize suggestion engine.
        
        Args:
            data_provider: StudentDataProvider instance
        """
        self.data_provider = data_provider
        
        # Register all rules
        self.rules = [
            # Time-based rules
            DeadlineRule(),
            PlacementSeasonRule(),
            
            # Context-based rules
            AttendanceRule(),
            ScholarshipEligibilityRule(),
            CGPAPerformanceRule(),
            PlacementEligibilityRule(),
        ]
        
        logger.info(f"ProactiveSuggestionEngine initialized with {len(self.rules)} rules")
    
    def get_suggestions(
        self,
        student_id: str,
        max_suggestions: int = 10,
        priority_filter: List[str] = None
    ) -> List[Dict]:
        """
        Get personalized proactive suggestions for a student.
        
        Args:
            student_id: Student ID
            max_suggestions: Maximum number of suggestions to return
            priority_filter: Optional list of priorities to filter (e.g., ["critical", "high"])
        
        Returns:
            List of suggestion dictionaries, sorted by priority
        """
        try:
            # Get complete student data
            student_data = self.data_provider.get_student_data(student_id)
            current_date = datetime.now()
            
            all_suggestions = []
            
            # Evaluate each rule
            for rule in self.rules:
                try:
                    suggestions = rule.evaluate(student_data, current_date)
                    
                    # Filter suggestions if needed
                    for suggestion in suggestions:
                        if rule.should_show(suggestion, student_data):
                            all_suggestions.append(suggestion)
                    
                except Exception as e:
                    logger.error(f"Rule {rule.__class__.__name__} failed: {e}")
                    continue
            
            # Apply priority filter if specified
            if priority_filter:
                all_suggestions = [
                    s for s in all_suggestions 
                    if s.priority in priority_filter
                ]
            
            # Sort by priority (critical > high > medium > low)
            priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
            all_suggestions.sort(key=lambda s: priority_order.get(s.priority, 999))
            
            # Return top N
            result = [s.to_dict() for s in all_suggestions[:max_suggestions]]
            
            logger.info(f"Generated {len(result)} suggestions for student {student_id}")
            return result
            
        except Exception as e:
            logger.error(f"Failed to generate suggestions for {student_id}: {e}")
            return []
    
    def get_suggestions_by_type(
        self,
        student_id: str,
        suggestion_type: str
    ) -> List[Dict]:
        """
        Get suggestions of a specific type.
        
        Args:
            student_id: Student ID
            suggestion_type: Type of suggestions (deadline, alert, opportunity, etc.)
        
        Returns:
            List of filtered suggestions
        """
        all_suggestions = self.get_suggestions(student_id, max_suggestions=100)
        
        return [s for s in all_suggestions if s["type"] == suggestion_type]
    
    def get_critical_alerts(self, student_id: str) -> List[Dict]:
        """
        Get only critical alerts for a student.
        
        Args:
            student_id: Student ID
        
        Returns:
            List of critical priority suggestions
        """
        return self.get_suggestions(
            student_id,
            max_suggestions=5,
            priority_filter=["critical"]
        )
